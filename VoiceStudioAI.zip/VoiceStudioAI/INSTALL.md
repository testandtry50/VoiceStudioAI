# VoiceStudio AI - Phase 1 (Kokoro) - build and install from a phone

Phase 1 scope: Kokoro offline TTS, unlimited-length text (auto-chunked), playback, WAV export.
Nothing here has been run on a device yet: the first CI build may need a fix round. If it fails, the run
summary shows the exact compiler error - send it back and it gets fixed.

## One-time GitHub setup (mobile browser; if a button is missing, use Chrome menu > "Desktop site")
1. Create a new repository (private is fine).
2. Repository > Add file > Create new file. Name it exactly `.github/workflows/build-debug.yml`
   (typing the slashes creates the folders). Paste the workflow from the chat. Commit.
3. Repository > Add file > Upload files. Upload `VoiceStudioAI.zip` (do NOT unzip it). Commit.
   Keep exactly one VoiceStudioAI zip in the repository root.

## Build
4. Actions tab > "Build debug APK" > Run workflow (leave ABIs as arm64-v8a) > Run workflow.
5. First run takes roughly 8-15 minutes (Gradle and Android dependencies download once).
6. Open the finished run. The summary lists errors, if any, and the native libraries inside the APK.
7. At the bottom, under Artifacts, download `VoiceStudioAI-debug-apk` (a zip containing app-debug.apk).
   If anything failed, also download `build-logs`.

## Install
8. Unzip the download (Files by Google > tap the zip > Extract).
9. Tap app-debug.apk. Android asks permission to install from this source (your browser or Files app): allow it.
   Play Protect may warn about an unknown developer: choose "Install anyway".
10. Open VoiceStudio AI > Generate > Download model (large, use Wi-Fi, keep the app open) > type text > Generate.

## Updating
Upload a new zip with the same name (it replaces the old one), run the workflow again, install the new APK
over the old one. The APK is always signed with the same fixed debug key, so the update keeps your
downloaded model. If Android says the app conflicts with an existing package, uninstall the old build first
(that deletes the downloaded model).

## Pinned versions
- sherpa-onnx 2.0.1 official AAR, SHA-256 checked in CI (`sherpa-onnx.properties`)
- Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.10.01 (`gradle/libs.versions.toml`)
- Model: kokoro-multi-lang-v1_0 from the official sherpa-onnx `tts-models` release
