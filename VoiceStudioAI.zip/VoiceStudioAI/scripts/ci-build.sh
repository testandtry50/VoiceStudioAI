#!/usr/bin/env bash
# CI entry point. Never hides a failure: the exit code is Gradle's, and logs are always written.
# Usage: scripts/ci-build.sh [abis]
set -uo pipefail
ABIS="${1:-arm64-v8a}"
mkdir -p build-logs
export LOG_DIR="$PWD/build-logs"

{
  echo "abis=$ABIS"
  java -version 2>&1
  gradle --version 2>&1 | head -n 15
  echo "ANDROID_HOME=${ANDROID_HOME:-unset}"
} > build-logs/environment.txt 2>&1

SDKMANAGER="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKMANAGER" ]; then
  yes 2>/dev/null | "$SDKMANAGER" --licenses > build-logs/sdk-licenses.txt 2>&1 || true
fi

bash scripts/fetch-sherpa-onnx.sh "$ABIS" 2>&1 | tee build-logs/fetch.log
if [ "${PIPESTATUS[0]}" -ne 0 ]; then
  echo "Dependency step failed - see build-logs/fetch.log"
  bash scripts/ci-summary.sh
  exit 1
fi

gradle :app:testDebugUnitTest :app:assembleDebug --continue --stacktrace --warning-mode all -PappAbis="$ABIS" 2>&1 | tee build-logs/gradle.log
STATUS=${PIPESTATUS[0]}
bash scripts/ci-summary.sh
exit "$STATUS"
