#!/usr/bin/env bash
# Downloads the pinned sherpa-onnx Android AAR, verifies its SHA-256 and sanity-checks its contents.
# Usage: scripts/fetch-sherpa-onnx.sh [abis, comma separated, default arm64-v8a]
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROPS="$ROOT/sherpa-onnx.properties"
LOG_DIR="${LOG_DIR:-$ROOT/build-logs}"
ABIS="${1:-arm64-v8a}"
mkdir -p "$LOG_DIR" "$ROOT/app/libs"

prop() { grep -E "^$1=" "$PROPS" | head -n1 | cut -d= -f2- | tr -d '[:space:]'; }
VERSION="$(prop version)"
SHA="$(prop aar_sha256)"
if [ -z "$VERSION" ] || [ -z "$SHA" ]; then
  echo "::error::sherpa-onnx.properties must define version and aar_sha256"; exit 1
fi
AAR="$ROOT/app/libs/sherpa-onnx-$VERSION.aar"
URL="${SHERPA_AAR_URL:-https://github.com/k2-fsa/sherpa-onnx/releases/download/v$VERSION/sherpa-onnx-$VERSION.aar}"

if [ ! -f "$AAR" ]; then
  echo "Downloading $URL"
  if ! curl --fail --location --retry 5 --retry-delay 5 --retry-all-errors -o "$AAR" "$URL"; then
    echo "::error::Could not download $URL (is the release asset name still sherpa-onnx-$VERSION.aar?)"
    rm -f "$AAR"; exit 1
  fi
fi

ACTUAL="$(sha256sum "$AAR" | cut -d' ' -f1)"
if [ "$ACTUAL" != "$SHA" ]; then
  echo "::error::Checksum mismatch for sherpa-onnx-$VERSION.aar. expected=$SHA actual=$ACTUAL. If you deliberately changed the version, copy the new sha256 from the GitHub release page into sherpa-onnx.properties."
  rm -f "$AAR"; exit 1
fi
echo "sherpa-onnx $VERSION AAR verified: sha256=$ACTUAL"

unzip -Z1 "$AAR" | sort > "$LOG_DIR/aar-contents.txt"
fail=0
for abi in ${ABIS//,/ }; do
  if ! grep -qx "jni/$abi/libsherpa-onnx-jni.so" "$LOG_DIR/aar-contents.txt"; then
    echo "::error::The AAR has no jni/$abi/libsherpa-onnx-jni.so - see aar-contents.txt in the build-logs artifact"
    fail=1
  fi
  if ! grep -qx "jni/$abi/libonnxruntime.so" "$LOG_DIR/aar-contents.txt"; then
    echo "::warning::The AAR has no separate jni/$abi/libonnxruntime.so (fine if it is linked statically)"
  fi
done

if ! grep -qx "classes.jar" "$LOG_DIR/aar-contents.txt"; then
  echo "::error::The AAR has no classes.jar"; fail=1
else
  unzip -p "$AAR" classes.jar > "$LOG_DIR/sherpa-classes.jar"
  unzip -Z1 "$LOG_DIR/sherpa-classes.jar" | sort > "$LOG_DIR/classes-contents.txt"
  for cls in OfflineTts OfflineTtsConfig OfflineTtsModelConfig OfflineTtsKokoroModelConfig GenerationConfig GeneratedAudio; do
    if ! grep -qx "com/k2fsa/sherpa/onnx/$cls.class" "$LOG_DIR/classes-contents.txt"; then
      echo "::error::classes.jar has no com.k2fsa.sherpa.onnx.$cls - the Kotlin API differs from what the app expects"
      fail=1
    fi
  done
  # Public signatures, kept in the logs so API mismatches are easy to diagnose.
  if command -v javap >/dev/null 2>&1; then
    javap -cp "$LOG_DIR/sherpa-classes.jar" \
      com.k2fsa.sherpa.onnx.OfflineTts com.k2fsa.sherpa.onnx.GenerationConfig \
      com.k2fsa.sherpa.onnx.OfflineTtsConfig com.k2fsa.sherpa.onnx.OfflineTtsModelConfig \
      com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig com.k2fsa.sherpa.onnx.GeneratedAudio \
      > "$LOG_DIR/sherpa-api.txt" 2>&1 || true
    # javap lists methods and getters (getDataDir), not bare property names, so only real method names are
    # hard requirements; property getters are matched case-insensitively and only produce warnings.
    for sym in generateWithConfigAndCallback release; do
      if ! grep -q "$sym" "$LOG_DIR/sherpa-api.txt"; then
        echo "::error::sherpa-onnx $VERSION API has no method '$sym' - see sherpa-api.txt in the build-logs artifact; the app code must be adapted to this version"
        fail=1
      fi
    done
    for getter in getDataDir getNumThreads getSilenceScale; do
      if ! grep -qi "$getter" "$LOG_DIR/sherpa-api.txt"; then
        echo "::warning::sherpa-api.txt has no $getter - check the file if the compile step fails"
      fi
    done
  fi
fi
exit $fail
