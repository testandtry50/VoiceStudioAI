#!/usr/bin/env bash
# Turns the Gradle log into something readable on a phone: inline error annotations plus a job summary.
set +e
LOG="build-logs/gradle.log"
OUT="${GITHUB_STEP_SUMMARY:-/dev/stdout}"
WS="${GITHUB_WORKSPACE:-$PWD}"
APK="$(ls app/build/outputs/apk/debug/*.apk 2>/dev/null | head -n1)"

if [ -f "$LOG" ]; then
  # Kotlin compile errors look like:  e: file:///path/File.kt:12:5 message
  sed -nE "s#^e: file://${WS}/([^:]+):([0-9]+):([0-9]+) (.*)#::error file=\1,line=\2,col=\3::\4#p" "$LOG" | head -n 50
fi

{
  echo "## VoiceStudio AI - build report"
  if [ -n "$APK" ]; then
    unzip -Z1 "$APK" | sort > build-logs/apk-contents.txt
    echo "**APK built:** \`$(basename "$APK")\` - $(du -h "$APK" | cut -f1) - sha256 \`$(sha256sum "$APK" | cut -d' ' -f1)\`"
    echo
    echo "Native libraries inside the APK:"
    echo '```'
    grep -E '^lib/' build-logs/apk-contents.txt
    echo '```'
    if ! grep -q '^lib/arm64-v8a/libsherpa-onnx-jni.so$' build-logs/apk-contents.txt; then
      echo "::error::APK has no lib/arm64-v8a/libsherpa-onnx-jni.so - it will crash on a phone."
      echo "**WARNING: the arm64-v8a sherpa-onnx library is missing from the APK.**"
    fi
    echo
    echo "Download it from the **Artifacts** section at the bottom of this run page (file: VoiceStudioAI-debug-apk)."
  else
    echo "**No APK was produced.**"
  fi

  if [ -f "$LOG" ]; then
    if grep -q "^e: " "$LOG"; then
      echo; echo "### Kotlin compile errors"; echo '```'
      grep "^e: " "$LOG" | sed "s#file://${WS}/##" | head -n 40
      echo '```'
    fi
    if grep -q "What went wrong" "$LOG"; then
      echo; echo "### Gradle failure"; echo '```'
      awk '/\* What went wrong:/{f=1} f{print} /\* Try:/{f=0}' "$LOG" | head -n 40
      echo '```'
    fi
    if grep -qE "Test .* FAILED|tests completed, .* failed" "$LOG"; then
      echo; echo "### Unit test failures"; echo '```'
      grep -E "Test .* FAILED|tests completed" "$LOG" | head -n 20
      echo '```'
    fi
  else
    echo; echo "No Gradle log found - the build stopped before Gradle ran. Open the first failed step above."
  fi
  echo
  echo "Full logs: download the **build-logs** artifact (gradle.log, environment.txt, aar-contents.txt, sherpa-api.txt, reports)."
} >> "$OUT"
exit 0
