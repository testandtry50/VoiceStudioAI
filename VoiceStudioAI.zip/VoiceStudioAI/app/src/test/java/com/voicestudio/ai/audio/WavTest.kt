package com.voicestudio.ai.audio

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class WavTest {
    @Test fun headerIs44BytesAndRoundTrips() {
        val pcm = Wav.floatToPcm16(floatArrayOf(0f, 0.5f, -0.5f, 1f))
        val file = File.createTempFile("wavtest", ".wav")
        try {
            file.writeBytes(Wav.header(24000, pcm.size.toLong()) + pcm)
            assertEquals(44 + pcm.size, file.length().toInt())
            val info = Wav.readInfo(file)
            assertEquals(24000, info.sampleRate)
            assertEquals(pcm.size.toLong(), info.dataBytes)
        } finally {
            file.delete()
        }
    }

    @Test fun floatsAreConvertedAndClamped() {
        val b = ByteBuffer.wrap(Wav.floatToPcm16(floatArrayOf(0f, 1f, -1f, 2f, -3f))).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals(0, b.getShort(0).toInt())
        assertEquals(32767, b.getShort(2).toInt())
        assertEquals(-32767, b.getShort(4).toInt())
        assertEquals(32767, b.getShort(6).toInt())
        assertEquals(-32767, b.getShort(8).toInt())
    }

    @Test fun silenceHasTheRightLength() {
        assertEquals(24000 * 2 / 2, Wav.silence(24000, 500).size)   // 0.5 s of 16-bit mono
    }
}
