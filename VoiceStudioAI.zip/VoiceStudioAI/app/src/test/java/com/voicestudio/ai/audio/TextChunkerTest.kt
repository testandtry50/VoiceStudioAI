package com.voicestudio.ai.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextChunkerTest {
    @Test fun blankTextGivesNoChunks() {
        assertTrue(TextChunker.split("").isEmpty())
        assertTrue(TextChunker.split("  \n\n  ").isEmpty())
    }

    @Test fun shortTextIsOneChunk() {
        val chunks = TextChunker.split("Hello world. How are you?")
        assertEquals(1, chunks.size)
        assertEquals("Hello world. How are you?", chunks[0].text)
    }

    @Test fun paragraphsBecomeSeparateChunksWithLongPause() {
        val chunks = TextChunker.split("First paragraph.\n\nSecond paragraph.")
        assertEquals(2, chunks.size)
        assertEquals("First paragraph.", chunks[0].text)
        assertEquals(TextChunker.PARAGRAPH_PAUSE_MS, chunks[0].pauseAfterMs)
        assertEquals("Second paragraph.", chunks[1].text)
    }

    @Test fun singleNewlineIsJustASpace() {
        val chunks = TextChunker.split("Hello\nworld.")
        assertEquals(1, chunks.size)
        assertEquals("Hello world.", chunks[0].text)
    }

    @Test fun longTextIsSplitIntoBoundedChunksWithoutLosingWords() {
        val original = (1..200).joinToString(" ") { "This is sentence number $it." }
        val chunks = TextChunker.split(original, maxChars = 100)
        assertTrue(chunks.size > 20)
        assertTrue(chunks.all { it.text.length <= 100 })
        assertEquals(original, chunks.joinToString(" ") { it.text })
    }

    @Test fun textWithoutSpacesIsHardSplit() {
        val chunks = TextChunker.split("a".repeat(1000), maxChars = 100)
        assertTrue(chunks.all { it.text.length <= 100 })
        assertEquals(1000, chunks.sumOf { it.text.length })
    }

    @Test fun midSentenceChunksGetShortPause() {
        val chunks = TextChunker.split("One. Two. Three. Four. Five. Six.", maxChars = 20)
        assertTrue(chunks.size > 1)
        assertEquals(TextChunker.SENTENCE_PAUSE_MS, chunks.first().pauseAfterMs)
        assertEquals(TextChunker.PARAGRAPH_PAUSE_MS, chunks.last().pauseAfterMs)
    }

    @Test fun chineseSentencesSplitWithoutWhitespace() {
        val chunks = TextChunker.split("\u4f60\u597d\u3002\u4e16\u754c\uff01", maxChars = 20)
        assertEquals(1, chunks.size)
        assertEquals("\u4f60\u597d\u3002\u4e16\u754c\uff01", chunks[0].text)
        val sentences = (1..100).joinToString("") { "\u8fd9\u662f\u7b2c${it}\u53e5\u8bdd\u3002" }
        val many = TextChunker.split(sentences)
        assertTrue(many.size > 1)
        assertTrue(many.all { it.text.length <= TextChunker.DEFAULT_MAX_CHARS_CJK })
    }

    @Test fun cjkTextUsesSmallerChunks() {
        assertEquals(TextChunker.DEFAULT_MAX_CHARS_CJK, TextChunker.defaultMaxChars("\u4f60\u597d\u4e16\u754c\u3002"))
        assertEquals(TextChunker.DEFAULT_MAX_CHARS, TextChunker.defaultMaxChars("Hello world."))
    }
}
