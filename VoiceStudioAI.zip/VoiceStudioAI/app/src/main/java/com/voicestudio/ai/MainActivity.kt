package com.voicestudio.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.voicestudio.ai.ui.generate.GenerateScreen

private enum class Tab(val label: String, val icon: ImageVector, val note: String) {
    GENERATE("Generate", Icons.Default.PlayArrow, ""),
    STORE("Model Store", Icons.Default.ShoppingCart, "Not built yet - planned for Phase 2. For now the Generate tab downloads Kokoro directly."),
    LIBRARY("Library", Icons.AutoMirrored.Filled.List, "Not built yet - planned for Phase 4. Use Save WAV on the Generate tab for now."),
    SETTINGS("Settings", Icons.Default.Settings, "Not built yet - planned for Phase 4. CPU threads can be changed on the Generate tab."),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var tab by remember { mutableStateOf(Tab.GENERATE) }
                    Scaffold(bottomBar = {
                        NavigationBar {
                            Tab.entries.forEach { t ->
                                NavigationBarItem(
                                    selected = tab == t,
                                    onClick = { tab = t },
                                    icon = { Icon(t.icon, contentDescription = t.label) },
                                    label = { Text(t.label) },
                                )
                            }
                        }
                    }) { padding ->
                        if (tab == Tab.GENERATE) {
                            GenerateScreen(modifier = Modifier.padding(padding))
                        } else {
                            Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
                                Text(tab.note)
                            }
                        }
                    }
                }
            }
        }
    }
}
