package com.voicestudio.ai.engine

/** Model families. Each family gets its own engine - they do not share one inference path. */
enum class ModelFamily { KOKORO }

/** A model that is fully extracted on disk. */
data class InstalledModel(val id: String, val family: ModelFamily, val dir: String)

class SynthResult(val samples: FloatArray, val sampleRate: Int)

/** Engines are not thread-safe: the generation pipeline owns one instance and calls it sequentially. */
interface TtsEngine {
    /** Blocking and heavy (loads hundreds of MB) - call off the main thread. */
    fun load(model: InstalledModel, numThreads: Int)

    /**
     * Synthesises one already-chunked piece of text. Returns null if [shouldContinue] turned false
     * (cancelled); throws on engine errors.
     */
    fun synthesize(text: String, speakerId: Int, speed: Float, shouldContinue: () -> Boolean): SynthResult?

    fun release()
}
