package com.voicestudio.ai.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.voicestudio.ai.AppLog
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Streams a WAV written by [Wav] through AudioTrack, with pause/resume/stop. */
class WavPlayer {
    enum class State { IDLE, PLAYING, PAUSED }

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state
    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs

    @Volatile private var paused = false
    @Volatile private var stopRequested = false
    private var thread: Thread? = null

    @Synchronized
    fun play(file: File) {
        stop()
        val info = try {
            Wav.readInfo(file)
        } catch (e: IOException) {
            AppLog.log("Play", "cannot read ${file.name}", e)
            return
        }
        paused = false
        stopRequested = false
        _positionMs.value = 0
        _state.value = State.PLAYING
        thread = Thread({ runPlayback(file, info) }, "wav-player").also { it.start() }
    }

    fun pause() {
        if (_state.value == State.PLAYING) {
            paused = true
            _state.value = State.PAUSED
        }
    }

    fun resume() {
        if (_state.value == State.PAUSED) {
            paused = false
            _state.value = State.PLAYING
        }
    }

    @Synchronized
    fun stop() {
        stopRequested = true
        paused = false
        thread?.join(1500)
        thread = null
        _state.value = State.IDLE
        _positionMs.value = 0
    }

    private fun runPlayback(file: File, info: Wav.Info) {
        var track: AudioTrack? = null
        try {
            val minBuffer = AudioTrack.getMinBufferSize(
                info.sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(info.sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(maxOf(minBuffer * 4, 32768))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()

            val totalFrames = info.dataBytes / 2
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(Wav.HEADER_BYTES.toLong())
                val buffer = ByteArray(16384)
                var remaining = info.dataBytes
                while (remaining > 0 && !stopRequested) {
                    waitWhilePaused(track)
                    if (stopRequested) break
                    val toRead = minOf(buffer.size.toLong(), remaining).toInt() and 1.inv()
                    if (toRead <= 0) break
                    raf.readFully(buffer, 0, toRead)
                    var offset = 0
                    while (offset < toRead && !stopRequested) {
                        val written = track.write(buffer, offset, toRead - offset)
                        if (written < 0) throw IOException("AudioTrack.write returned $written")
                        offset += written
                    }
                    remaining -= toRead
                    _positionMs.value = track.playbackHeadPosition.toLong() * 1000 / info.sampleRate
                }

                // Everything is queued; wait for the tail to finish playing.
                var lastHead = -1
                var stalled = 0
                while (!stopRequested) {
                    if (waitWhilePaused(track)) stalled = 0
                    val head = track.playbackHeadPosition
                    _positionMs.value = head.toLong() * 1000 / info.sampleRate
                    if (head >= totalFrames) break
                    if (head == lastHead) {
                        if (++stalled > 100) break      // ~5 s without progress
                    } else {
                        stalled = 0
                        lastHead = head
                    }
                    Thread.sleep(50)
                }
            }
        } catch (e: Exception) {
            AppLog.log("Play", "playback error", e)
        } finally {
            try {
                track?.stop()
            } catch (_: Exception) {
            }
            track?.release()
            if (!stopRequested) {
                _state.value = State.IDLE
                _positionMs.value = 0
            }
        }
    }

    /** Returns true if it had to wait. */
    private fun waitWhilePaused(track: AudioTrack): Boolean {
        if (!paused) return false
        track.pause()
        while (paused && !stopRequested) Thread.sleep(40)
        if (!stopRequested) track.play()
        return true
    }
}
