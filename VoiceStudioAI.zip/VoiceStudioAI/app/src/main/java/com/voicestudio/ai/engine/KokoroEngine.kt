package com.voicestudio.ai.engine

import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig

/** Kokoro 82M (multi-language v1.0) through the pinned sherpa-onnx release. */
class KokoroEngine : TtsEngine {
    private var tts: OfflineTts? = null

    override fun load(model: InstalledModel, numThreads: Int) {
        release()
        val d = model.dir
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                kokoro = OfflineTtsKokoroModelConfig(
                    model = "$d/model.onnx",
                    voices = "$d/voices.bin",
                    tokens = "$d/tokens.txt",
                    dataDir = "$d/espeak-ng-data",
                    lexicon = "$d/lexicon-us-en.txt,$d/lexicon-zh.txt",
                ),
                numThreads = numThreads,
                debug = false,
            ),
        )
        tts = OfflineTts(config = config)
    }

    override fun synthesize(
        text: String,
        speakerId: Int,
        speed: Float,
        shouldContinue: () -> Boolean,
    ): SynthResult? {
        val engine = tts ?: error("Kokoro engine is not loaded")
        val generation = GenerationConfig(sid = speakerId, speed = speed, silenceScale = 0.2f)
        var cancelled = false
        val audio = engine.generateWithConfigAndCallback(
            text = text,
            config = generation,
            callback = { _ ->
                if (shouldContinue()) {
                    1
                } else {
                    cancelled = true
                    0
                }
            },
        )
        return if (cancelled) null else SynthResult(audio.samples, audio.sampleRate)
    }

    override fun release() {
        tts?.release()
        tts = null
    }
}

/** Speaker IDs from the sherpa-onnx documentation for kokoro-multi-lang-v1_0 (54 speakers, 24 kHz). */
object KokoroVoices {
    enum class Language(val label: String) { ENGLISH("English"), CHINESE("Chinese") }

    data class Voice(val sid: Int, val name: String, val description: String, val language: Language) {
        val label: String get() = "$name - $description"
    }

    val all: List<Voice> = listOf(
        v(0, "af_alloy", "American female"), v(1, "af_aoede", "American female"),
        v(2, "af_bella", "American female"), v(3, "af_heart", "American female"),
        v(4, "af_jessica", "American female"), v(5, "af_kore", "American female"),
        v(6, "af_nicole", "American female"), v(7, "af_nova", "American female"),
        v(8, "af_river", "American female"), v(9, "af_sarah", "American female"),
        v(10, "af_sky", "American female"),
        v(11, "am_adam", "American male"), v(12, "am_echo", "American male"),
        v(13, "am_eric", "American male"), v(14, "am_fenrir", "American male"),
        v(15, "am_liam", "American male"), v(16, "am_michael", "American male"),
        v(17, "am_onyx", "American male"), v(18, "am_puck", "American male"),
        v(19, "am_santa", "American male"),
        v(20, "bf_alice", "British female"), v(21, "bf_emma", "British female"),
        v(22, "bf_isabella", "British female"), v(23, "bf_lily", "British female"),
        v(24, "bm_daniel", "British male"), v(25, "bm_fable", "British male"),
        v(26, "bm_george", "British male"), v(27, "bm_lewis", "British male"),
        v(45, "zf_xiaobei", "Chinese female", Language.CHINESE),
        v(46, "zf_xiaoni", "Chinese female", Language.CHINESE),
        v(47, "zf_xiaoxiao", "Chinese female", Language.CHINESE),
        v(48, "zf_xiaoyi", "Chinese female", Language.CHINESE),
        v(49, "zm_yunjian", "Chinese male", Language.CHINESE),
        v(50, "zm_yunxi", "Chinese male", Language.CHINESE),
        v(51, "zm_yunxia", "Chinese male", Language.CHINESE),
        v(52, "zm_yunyang", "Chinese male", Language.CHINESE),
    )

    const val DEFAULT_ENGLISH_SID = 3   // af_heart
    const val DEFAULT_CHINESE_SID = 45  // zf_xiaobei

    fun forLanguage(language: Language): List<Voice> = all.filter { it.language == language }
    fun byId(sid: Int): Voice = all.first { it.sid == sid }

    private fun v(sid: Int, name: String, desc: String, language: Language = Language.ENGLISH) =
        Voice(sid, name, desc, language)
}
