package com.voicestudio.ai

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Tiny in-app logger. On a phone without a PC there is no logcat, so everything important is kept
 * in memory (shown in the Diagnostics panel) and appended to files/logs/app.log, which survives a crash.
 */
object AppLog {
    private const val MAX_LINES = 400
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines
    private var file: File? = null
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun init(context: Context) {
        val dir = File(context.filesDir, "logs").apply { mkdirs() }
        val f = File(dir, "app.log")
        if (f.exists() && f.length() > 512_000) f.delete()
        file = f
        val previous = if (f.exists()) f.readLines().takeLast(60) else emptyList()
        if (previous.isNotEmpty()) {
            _lines.value = listOf("--- end of previous session ---") + previous + "--- this session ---"
        }
    }

    @Synchronized
    fun log(tag: String, message: String, error: Throwable? = null) {
        val line = buildString {
            append(timeFormat.format(Date())).append(" [").append(tag).append("] ").append(message)
            if (error != null) append('\n').append(error.stackTraceToString())
        }
        Log.i("VoiceStudio", "[$tag] $message", error)
        try {
            file?.appendText(line + "\n")
        } catch (_: Exception) {
        }
        _lines.value = (_lines.value + line).takeLast(MAX_LINES)
    }

    fun dump(): String = _lines.value.joinToString("\n")
}
