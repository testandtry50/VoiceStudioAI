package com.voicestudio.ai

import android.app.Application
import com.voicestudio.ai.model.KokoroModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class VoiceStudioApp : Application() {
    /** Lives as long as the process, so a model download survives screen rotation and activity recreation. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var modelManager: KokoroModelManager
        private set

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            AppLog.log("CRASH", "Uncaught exception on thread ${thread.name}", error)
            previousHandler?.uncaughtException(thread, error)
        }
        modelManager = KokoroModelManager(this, appScope)
        AppLog.log("App", "started, abis=${android.os.Build.SUPPORTED_ABIS.joinToString()}")
    }
}
