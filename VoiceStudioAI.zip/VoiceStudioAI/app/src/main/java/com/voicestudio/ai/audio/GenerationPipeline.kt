package com.voicestudio.ai.audio

import com.voicestudio.ai.AppLog
import com.voicestudio.ai.engine.SynthResult
import com.voicestudio.ai.engine.TtsEngine
import java.io.File
import java.io.RandomAccessFile

data class GenerationProgress(
    val fraction: Float,
    val chunkIndex: Int,
    val chunkCount: Int,
    val audioSeconds: Double,
    val elapsedSeconds: Double,
    val etaSeconds: Double,
)

class GenerationResult(
    val file: File,
    val durationSeconds: Double,
    val chunkCount: Int,
    val failedChunks: List<Int>,
    val elapsedSeconds: Double,
) {
    val realTimeFactor: Double get() = if (durationSeconds > 0) elapsedSeconds / durationSeconds else 0.0
}

/**
 * Chunks the text, synthesises chunk by chunk and streams 16-bit PCM straight to disk, so memory use
 * stays flat no matter how long the story is. Pauses between chunks are inserted as silence.
 */
class GenerationPipeline(private val engine: TtsEngine) {

    /** Blocking. Returns null if cancelled. Throws if nothing could be generated. */
    fun run(
        text: String,
        speakerId: Int,
        speed: Float,
        outFile: File,
        shouldContinue: () -> Boolean,
        onProgress: (GenerationProgress) -> Unit,
    ): GenerationResult? {
        val chunks = TextChunker.split(text)
        require(chunks.isNotEmpty()) { "There is no text to read." }
        val totalChars = chunks.sumOf { it.text.length }.coerceAtLeast(1)
        outFile.parentFile?.mkdirs()
        val part = File(outFile.parentFile, outFile.name + ".part")
        val startNs = System.nanoTime()
        AppLog.log("Gen", "start: ${text.length} chars -> ${chunks.size} chunks, sid=$speakerId speed=$speed")

        var sampleRate = 0
        var dataBytes = 0L
        var charsDone = 0
        var cancelled = false
        val failed = mutableListOf<Int>()

        try {
            RandomAccessFile(part, "rw").use { raf ->
                raf.setLength(0)
                raf.write(ByteArray(Wav.HEADER_BYTES))   // real header is written at the end
                for ((i, chunk) in chunks.withIndex()) {
                    if (!shouldContinue()) {
                        cancelled = true
                        break
                    }
                    AppLog.log("Gen", "chunk ${i + 1}/${chunks.size} (${chunk.text.length} chars)")
                    var result: SynthResult? = null
                    var chunkFailed = false
                    try {
                        result = engine.synthesize(chunk.text, speakerId, speed, shouldContinue)
                    } catch (e: Exception) {
                        chunkFailed = true
                        failed += i + 1
                        AppLog.log("Gen", "chunk ${i + 1} FAILED, skipping: \"${chunk.text.take(60)}\"", e)
                    }
                    if (!chunkFailed && result == null) {
                        cancelled = true
                        break
                    }
                    if (result != null) {
                        if (sampleRate == 0) sampleRate = result.sampleRate
                        val pcm = Wav.floatToPcm16(result.samples)
                        raf.write(pcm)
                        dataBytes += pcm.size
                    }
                    if (i < chunks.lastIndex && sampleRate > 0) {
                        val gap = Wav.silence(sampleRate, chunk.pauseAfterMs)
                        raf.write(gap)
                        dataBytes += gap.size
                    }
                    charsDone += chunk.text.length
                    val elapsed = (System.nanoTime() - startNs) / 1e9
                    val fraction = charsDone.toFloat() / totalChars
                    onProgress(
                        GenerationProgress(
                            fraction = fraction,
                            chunkIndex = i + 1,
                            chunkCount = chunks.size,
                            audioSeconds = if (sampleRate > 0) dataBytes / 2.0 / sampleRate else 0.0,
                            elapsedSeconds = elapsed,
                            etaSeconds = if (fraction > 0f) elapsed * (1 - fraction) / fraction else 0.0,
                        ),
                    )
                }
                if (!cancelled && sampleRate > 0) {
                    raf.seek(0)
                    raf.write(Wav.header(sampleRate, dataBytes))
                }
            }
        } catch (e: Throwable) {
            part.delete()
            throw e
        }

        if (cancelled) {
            part.delete()
            AppLog.log("Gen", "cancelled")
            return null
        }
        if (sampleRate == 0) {
            part.delete()
            throw IllegalStateException("All ${chunks.size} chunks failed. Open Diagnostics for details.")
        }
        outFile.delete()
        if (!part.renameTo(outFile)) throw IllegalStateException("Could not finalise ${outFile.name}")

        val seconds = dataBytes / 2.0 / sampleRate
        val elapsed = (System.nanoTime() - startNs) / 1e9
        AppLog.log(
            "Gen",
            "done: %.1fs audio in %.1fs (RTF %.2f), %d failed chunks".format(seconds, elapsed, elapsed / seconds, failed.size),
        )
        return GenerationResult(outFile, seconds, chunks.size, failed, elapsed)
    }
}
