package com.voicestudio.ai.audio

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal 16-bit mono PCM WAV helpers. */
object Wav {
    const val HEADER_BYTES = 44

    data class Info(val sampleRate: Int, val dataBytes: Long)

    fun header(sampleRate: Int, dataBytes: Long): ByteArray {
        val b = ByteBuffer.allocate(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray(Charsets.US_ASCII))
        b.putInt((36L + dataBytes).toInt())
        b.put("WAVE".toByteArray(Charsets.US_ASCII))
        b.put("fmt ".toByteArray(Charsets.US_ASCII))
        b.putInt(16)
        b.putShort(1)                 // PCM
        b.putShort(1)                 // mono
        b.putInt(sampleRate)
        b.putInt(sampleRate * 2)      // byte rate
        b.putShort(2)                 // block align
        b.putShort(16)                // bits per sample
        b.put("data".toByteArray(Charsets.US_ASCII))
        b.putInt(dataBytes.toInt())
        return b.array()
    }

    fun floatToPcm16(samples: FloatArray): ByteArray {
        val b = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (s in samples) {
            b.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        }
        return b.array()
    }

    fun silence(sampleRate: Int, millis: Int): ByteArray =
        ByteArray((sampleRate.toLong() * millis / 1000).toInt() * 2)

    /** Reads the header written by [header]. Throws if the file is not a 16-bit mono PCM WAV. */
    fun readInfo(file: File): Info {
        RandomAccessFile(file, "r").use { raf ->
            val h = ByteArray(HEADER_BYTES)
            raf.readFully(h)
            val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            fun tag(offset: Int) = String(h, offset, 4, Charsets.US_ASCII)
            if (tag(0) != "RIFF" || tag(8) != "WAVE" || tag(12) != "fmt " || tag(36) != "data") {
                throw IOException("Not a WAV file written by VoiceStudio AI: ${file.name}")
            }
            if (b.getShort(20).toInt() != 1 || b.getShort(22).toInt() != 1 || b.getShort(34).toInt() != 16) {
                throw IOException("Unsupported WAV format (expected 16-bit mono PCM)")
            }
            val rate = b.getInt(24)
            val data = b.getInt(40).toLong() and 0xFFFFFFFFL
            return Info(rate, minOf(data, raf.length() - HEADER_BYTES))
        }
    }
}
