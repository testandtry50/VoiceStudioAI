package com.voicestudio.ai.ui.generate

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.voicestudio.ai.AppLog
import com.voicestudio.ai.audio.WavPlayer
import com.voicestudio.ai.engine.KokoroVoices
import com.voicestudio.ai.model.ModelState

@Composable
fun GenerateScreen(modifier: Modifier = Modifier, vm: GenerateViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val model by vm.modelState.collectAsStateWithLifecycle()
    val playerState by vm.playerState.collectAsStateWithLifecycle()
    val positionMs by vm.positionMs.collectAsStateWithLifecycle()
    val logLines by AppLog.lines.collectAsStateWithLifecycle()

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) vm.saveTo(uri)
    }

    val view = LocalView.current
    val keepScreenOn = ui.generating || model is ModelState.Downloading
    DisposableEffect(keepScreenOn) {
        view.keepScreenOn = keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    Column(
        modifier = modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Generate", style = MaterialTheme.typography.headlineSmall)

        ModelCard(model, vm::downloadModel, vm::cancelDownload, vm::deleteModel)

        OutlinedTextField(
            value = ui.text,
            onValueChange = vm::setText,
            modifier = Modifier.fillMaxWidth(),
            minLines = 6,
            label = { Text("Text to read aloud") },
            supportingText = { Text("${ui.text.length} characters - no length limit, long text is split automatically") },
            enabled = !ui.generating,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            KokoroVoices.Language.entries.forEach { lang ->
                FilterChip(
                    selected = ui.language == lang,
                    onClick = { vm.setLanguage(lang) },
                    label = { Text(lang.label) },
                    enabled = !ui.generating,
                )
            }
        }

        VoicePicker(ui.language, ui.speakerId, !ui.generating, vm::setSpeaker)

        Text("Speed: %.2fx".format(ui.speed))
        Slider(value = ui.speed, onValueChange = vm::setSpeed, valueRange = 0.5f..2.0f, enabled = !ui.generating)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("CPU threads: ${ui.threads}")
            OutlinedButton(onClick = { vm.setThreads(ui.threads - 1) }, enabled = !ui.generating && ui.threads > 1) { Text("-") }
            OutlinedButton(onClick = { vm.setThreads(ui.threads + 1) }, enabled = !ui.generating && ui.threads < vm.maxThreadCount) { Text("+") }
        }

        if (ui.generating) {
            Button(onClick = vm::stopGeneration, modifier = Modifier.fillMaxWidth()) { Text("Stop") }
        } else {
            Button(
                onClick = vm::generate,
                enabled = model is ModelState.Installed && ui.text.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Generate") }
        }

        if (ui.generating || ui.status.isNotEmpty()) {
            if (ui.generating) LinearProgressIndicator(progress = { ui.progress }, modifier = Modifier.fillMaxWidth())
            Text(ui.status, style = MaterialTheme.typography.bodySmall)
        }

        ui.message?.let { msg ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(msg, modifier = Modifier.weight(1f))
                    TextButton(onClick = vm::dismissMessage) { Text("OK") }
                }
            }
        }

        ui.result?.let { result ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Result: %.1f s of audio, generated in %.1f s".format(result.durationSeconds, result.elapsedSeconds))
                    Text("Position: %.1f s".format(positionMs / 1000.0), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (playerState) {
                            WavPlayer.State.IDLE -> Button(onClick = vm::play) { Text("Play") }
                            WavPlayer.State.PLAYING -> Button(onClick = vm::pause) { Text("Pause") }
                            WavPlayer.State.PAUSED -> Button(onClick = vm::resume) { Text("Resume") }
                        }
                        OutlinedButton(onClick = vm::stopPlayback, enabled = playerState != WavPlayer.State.IDLE) { Text("Stop") }
                    }
                    OutlinedButton(
                        onClick = { saveLauncher.launch("voicestudio-${System.currentTimeMillis()}.wav") },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save WAV...") }
                    Text(
                        "The latest result is kept until the next generation. Save it to keep it.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        DiagnosticsPanel(logLines)
    }
}

@Composable
private fun ModelCard(state: ModelState, onDownload: () -> Unit, onCancel: () -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kokoro 82M (v1.0, English + Chinese)", style = MaterialTheme.typography.titleMedium)
            when (state) {
                is ModelState.NotInstalled -> {
                    Text("Not installed. This is a large one-time download (hundreds of MB) from the official sherpa-onnx releases. Use Wi-Fi and keep the app open until it finishes.")
                    Button(onClick = onDownload) { Text("Download model") }
                }
                is ModelState.Downloading -> {
                    if (state.totalBytes > 0) {
                        LinearProgressIndicator(progress = { (state.bytesRead.toFloat() / state.totalBytes).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text("Downloading and unpacking: ${state.bytesRead / 1_048_576} of ${state.totalBytes / 1_048_576} MB")
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text("Connecting...")
                    }
                    OutlinedButton(onClick = onCancel) { Text("Cancel") }
                }
                is ModelState.Installed -> {
                    Text("Installed and verified (all required files present). Works fully offline.")
                    TextButton(onClick = onDelete) { Text("Remove model") }
                }
                is ModelState.Failed -> {
                    Text("Download failed: ${state.message}", color = MaterialTheme.colorScheme.error)
                    Button(onClick = onDownload) { Text("Try again") }
                }
            }
        }
    }
}

@Composable
private fun VoicePicker(language: KokoroVoices.Language, selected: Int, enabled: Boolean, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val voices = KokoroVoices.forLanguage(language)
    Column {
        OutlinedButton(onClick = { open = true }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
            Text("Voice: ${KokoroVoices.byId(selected).label}")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            voices.forEach { voice ->
                DropdownMenuItem(
                    text = { Text(voice.label) },
                    onClick = {
                        onSelect(voice.sid)
                        open = false
                    },
                )
            }
        }
    }
}

@Composable
private fun DiagnosticsPanel(lines: List<String>) {
    var show by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { show = !show }) { Text(if (show) "Hide diagnostics" else "Show diagnostics") }
        if (show) {
            Text(
                lines.takeLast(80).joinToString("\n").ifEmpty { "(no log lines yet)" },
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
            )
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(AppLog.dump())) }) { Text("Copy log") }
        }
    }
}
