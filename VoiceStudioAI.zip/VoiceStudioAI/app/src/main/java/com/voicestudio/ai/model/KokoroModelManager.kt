package com.voicestudio.ai.model

import android.content.Context
import com.voicestudio.ai.AppLog
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream

sealed interface ModelState {
    data object NotInstalled : ModelState
    data class Downloading(val bytesRead: Long, val totalBytes: Long) : ModelState
    data class Installed(val dir: File) : ModelState
    data class Failed(val message: String) : ModelState
}

object KokoroModel {
    const val ID = "kokoro-multi-lang-v1_0"
    // Official sherpa-onnx model release (kokoro v1.0 from hexgrad/Kokoro-82M, Chinese + English).
    const val URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_0.tar.bz2"
    val REQUIRED_FILES = listOf("model.onnx", "voices.bin", "tokens.txt", "lexicon-us-en.txt", "lexicon-zh.txt", "espeak-ng-data")
}

/**
 * Phase 1: a single-model installer. It streams the official .tar.bz2 straight through bzip2 + tar into a
 * temporary folder (no 300+ MB archive is ever stored), verifies that every required file exists, then
 * moves the folder into place atomically. Interrupted downloads restart from zero; Phase 2 adds resume
 * and SHA-256 checks.
 */
class KokoroModelManager(context: Context, private val scope: CoroutineScope) {
    private val modelsRoot = File(context.filesDir, "models")
    private val finalDir = File(modelsRoot, KokoroModel.ID)
    private val _state = MutableStateFlow<ModelState>(ModelState.NotInstalled)
    val state: StateFlow<ModelState> = _state
    private var job: Job? = null

    init {
        refresh()
    }

    fun refresh() {
        val problem = verify(finalDir)
        _state.value = if (problem == null) ModelState.Installed(finalDir) else ModelState.NotInstalled
        if (problem != null && finalDir.exists()) AppLog.log("Model", "installed copy is incomplete: $problem")
    }

    /** Null when the folder is complete, otherwise what is wrong. */
    fun verify(dir: File): String? {
        if (!dir.isDirectory) return "folder missing"
        val missing = KokoroModel.REQUIRED_FILES.filter { !File(dir, it).exists() }
        if (missing.isNotEmpty()) return "missing: ${missing.joinToString()}"
        if (File(dir, "model.onnx").length() < 1_000_000L) return "model.onnx looks truncated"
        return null
    }

    fun startDownload() {
        if (job?.isActive == true) return
        job = scope.launch(Dispatchers.IO) {
            val tmp = File(modelsRoot, ".download-${KokoroModel.ID}")
            try {
                modelsRoot.mkdirs()
                tmp.deleteRecursively()
                tmp.mkdirs()
                _state.value = ModelState.Downloading(0, -1)
                AppLog.log("Model", "download starts: ${KokoroModel.URL}")

                val conn = URL(KokoroModel.URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 20_000
                conn.readTimeout = 60_000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "VoiceStudioAI/0.1")
                val code = conn.responseCode
                if (code != 200) error("Server answered HTTP $code (${conn.url.host})")
                val total = conn.contentLengthLong
                AppLog.log("Model", "connected to ${conn.url.host}, size=$total bytes")
                if (total > 0 && modelsRoot.usableSpace < total * 2) {
                    error("Not enough free storage: need about ${total * 2 / 1_048_576} MB, have ${modelsRoot.usableSpace / 1_048_576} MB")
                }

                var lastEmit = 0L
                val counting = CountingStream(conn.inputStream) { read ->
                    val now = System.nanoTime()
                    if (now - lastEmit > 250_000_000L) {
                        lastEmit = now
                        _state.value = ModelState.Downloading(read, total)
                    }
                }
                extractTarBz2(counting, tmp)

                val extracted = File(tmp, KokoroModel.ID)
                verify(extracted)?.let { error("Archive is incomplete ($it)") }
                finalDir.deleteRecursively()
                if (!extracted.renameTo(finalDir)) error("Could not move the model into place")
                tmp.deleteRecursively()
                AppLog.log("Model", "installed at ${finalDir.path}")
                _state.value = ModelState.Installed(finalDir)
            } catch (e: CancellationException) {
                tmp.deleteRecursively()
                AppLog.log("Model", "download cancelled")
                refresh()
                throw e
            } catch (e: Throwable) {
                tmp.deleteRecursively()
                AppLog.log("Model", "download failed", e)
                _state.value = ModelState.Failed(e.message ?: e::class.java.simpleName)
            }
        }
    }

    fun cancelDownload() {
        job?.cancel()
    }

    fun delete() {
        job?.cancel()
        finalDir.deleteRecursively()
        AppLog.log("Model", "model removed")
        refresh()
    }

    private fun CoroutineScope.extractTarBz2(input: InputStream, targetRoot: File) {
        val rootPath = targetRoot.canonicalPath + File.separator
        BZip2CompressorInputStream(BufferedInputStream(input, 1 shl 16)).use { bz ->
            TarArchiveInputStream(bz).use { tar ->
                var entry: TarArchiveEntry? = tar.nextEntry
                while (entry != null) {
                    ensureActive()
                    val out = File(targetRoot, entry.name)
                    if (!out.canonicalPath.startsWith(rootPath)) error("Unsafe path in archive: ${entry.name}")
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else if (entry.isFile) {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { tar.copyTo(it, 1 shl 16) }
                    }
                    entry = tar.nextEntry
                }
            }
        }
    }

    private class CountingStream(input: InputStream, private val onProgress: (Long) -> Unit) : FilterInputStream(input) {
        private var count = 0L

        override fun read(): Int {
            val r = super.read()
            if (r >= 0) bump(1)
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len)
            if (r > 0) bump(r.toLong())
            return r
        }

        private fun bump(n: Long) {
            count += n
            onProgress(count)
        }
    }
}
