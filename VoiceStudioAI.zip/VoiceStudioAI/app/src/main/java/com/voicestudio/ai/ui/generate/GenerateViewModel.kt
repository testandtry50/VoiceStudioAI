package com.voicestudio.ai.ui.generate

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.voicestudio.ai.AppLog
import com.voicestudio.ai.VoiceStudioApp
import com.voicestudio.ai.audio.GenerationPipeline
import com.voicestudio.ai.audio.WavPlayer
import com.voicestudio.ai.engine.InstalledModel
import com.voicestudio.ai.engine.KokoroEngine
import com.voicestudio.ai.engine.KokoroVoices
import com.voicestudio.ai.engine.ModelFamily
import com.voicestudio.ai.model.KokoroModel
import com.voicestudio.ai.model.ModelState
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ResultInfo(val file: File, val durationSeconds: Double, val elapsedSeconds: Double, val failedChunks: List<Int>)

data class GenerateUiState(
    val text: String = "",
    val language: KokoroVoices.Language = KokoroVoices.Language.ENGLISH,
    val speakerId: Int = KokoroVoices.DEFAULT_ENGLISH_SID,
    val speed: Float = 1.0f,
    val threads: Int = defaultThreads(),
    val generating: Boolean = false,
    val progress: Float = 0f,
    val status: String = "",
    val result: ResultInfo? = null,
    val message: String? = null,
)

private fun maxThreads() = Runtime.getRuntime().availableProcessors().coerceIn(1, 8)
private fun defaultThreads() = minOf(4, maxThreads())

class GenerateViewModel(app: Application) : AndroidViewModel(app) {
    private val modelManager = (app as VoiceStudioApp).modelManager
    private val engine = KokoroEngine()
    private val player = WavPlayer()
    private var loadedDir: String? = null
    private var loadedThreads = -1
    private var job: Job? = null
    @Volatile private var cancelRequested = false

    private val _ui = MutableStateFlow(GenerateUiState())
    val ui: StateFlow<GenerateUiState> = _ui.asStateFlow()
    val modelState: StateFlow<ModelState> = modelManager.state
    val playerState: StateFlow<WavPlayer.State> = player.state
    val positionMs: StateFlow<Long> = player.positionMs
    val maxThreadCount: Int = maxThreads()

    private fun edit(block: GenerateUiState.() -> GenerateUiState) = _ui.update { it.block() }

    fun setText(text: String) = edit { copy(text = text) }
    fun setSpeed(speed: Float) = edit { copy(speed = speed) }
    fun setSpeaker(sid: Int) = edit { copy(speakerId = sid) }
    fun setThreads(n: Int) = edit { copy(threads = n.coerceIn(1, maxThreadCount)) }
    fun dismissMessage() = edit { copy(message = null) }

    fun setLanguage(language: KokoroVoices.Language) = edit {
        if (language == this.language) this else copy(
            language = language,
            speakerId = if (language == KokoroVoices.Language.ENGLISH) KokoroVoices.DEFAULT_ENGLISH_SID else KokoroVoices.DEFAULT_CHINESE_SID,
        )
    }

    fun downloadModel() = modelManager.startDownload()
    fun cancelDownload() = modelManager.cancelDownload()

    fun deleteModel() {
        stopGeneration()
        player.stop()
        viewModelScope.launch(Dispatchers.IO) {
            job?.join()
            engine.release()
            loadedDir = null
            modelManager.delete()
            edit { copy(result = null) }
        }
    }

    fun generate() {
        val installed = modelManager.state.value as? ModelState.Installed ?: return
        val state = _ui.value
        val text = state.text.trim()
        if (text.isEmpty()) {
            edit { copy(message = "Type or paste some text first.") }
            return
        }
        if (job?.isActive == true) return
        player.stop()
        cancelRequested = false
        edit { copy(generating = true, progress = 0f, status = "Loading Kokoro model...", message = null, result = null) }

        job = viewModelScope.launch(Dispatchers.Default) {
            try {
                ensureLoaded(installed.dir, state.threads)
                val audioDir = File(getApplication<Application>().filesDir, "audio").apply { mkdirs() }
                val out = File(audioDir, "gen-${System.currentTimeMillis()}.wav")
                edit { copy(status = "Generating...") }
                val result = GenerationPipeline(engine).run(
                    text = text,
                    speakerId = state.speakerId,
                    speed = state.speed,
                    outFile = out,
                    shouldContinue = { !cancelRequested },
                ) { p ->
                    edit {
                        copy(
                            progress = p.fraction,
                            status = "Chunk ${p.chunkIndex}/${p.chunkCount} - %.0fs of audio, about %.0fs left".format(p.audioSeconds, p.etaSeconds),
                        )
                    }
                }
                if (result == null) {
                    edit { copy(generating = false, progress = 0f, status = "Stopped.") }
                } else {
                    audioDir.listFiles { f -> f.name.startsWith("gen-") && f != out }?.forEach { it.delete() }
                    val warning = if (result.failedChunks.isEmpty()) null
                    else "${result.failedChunks.size} chunk(s) failed and were skipped (chunk ${result.failedChunks.joinToString()}). See Diagnostics."
                    edit {
                        copy(
                            generating = false, progress = 1f, status = "Done.",
                            result = ResultInfo(result.file, result.durationSeconds, result.elapsedSeconds, result.failedChunks),
                            message = warning,
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                AppLog.log("Gen", "generation failed", e)
                edit { copy(generating = false, status = "", message = "Generation failed: ${e.message ?: e::class.java.simpleName}") }
            }
        }
    }

    private fun ensureLoaded(dir: File, threads: Int) {
        if (loadedDir == dir.path && loadedThreads == threads) return
        val start = System.nanoTime()
        AppLog.log("Engine", "loading Kokoro ($threads threads)")
        engine.load(InstalledModel(KokoroModel.ID, ModelFamily.KOKORO, dir.path), threads)
        loadedDir = dir.path
        loadedThreads = threads
        AppLog.log("Engine", "loaded in %.1fs".format((System.nanoTime() - start) / 1e9))
    }

    fun stopGeneration() {
        cancelRequested = true
    }

    fun play() {
        _ui.value.result?.let { player.play(it.file) }
    }

    fun pause() = player.pause()
    fun resume() = player.resume()
    fun stopPlayback() = player.stop()

    fun saveTo(uri: Uri) {
        val src = _ui.value.result?.file ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val resolver = getApplication<Application>().contentResolver
                val out = resolver.openOutputStream(uri) ?: error("Cannot open the destination file")
                out.use { o -> src.inputStream().use { it.copyTo(o, 1 shl 16) } }
                AppLog.log("Save", "WAV exported (${src.length() / 1024} KB)")
                edit { copy(message = "WAV saved.") }
            } catch (e: Exception) {
                AppLog.log("Save", "export failed", e)
                edit { copy(message = "Save failed: ${e.message ?: e::class.java.simpleName}") }
            }
        }
    }

    override fun onCleared() {
        cancelRequested = true
        player.stop()
        engine.release()
    }
}
