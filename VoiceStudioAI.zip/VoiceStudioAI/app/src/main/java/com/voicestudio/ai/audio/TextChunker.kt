package com.voicestudio.ai.audio

/** A piece of text sent to the engine in one call, plus the silence to insert after its audio. */
data class TextChunk(val text: String, val pauseAfterMs: Int)

/**
 * Splits text of any length into engine-sized chunks. There is no limit on total length;
 * [maxChars] only bounds a single chunk so memory and latency stay predictable.
 * Break priority: paragraph > sentence > comma/semicolon > word.
 */
object TextChunker {
    const val SENTENCE_PAUSE_MS = 250
    const val PARAGRAPH_PAUSE_MS = 650
    const val DEFAULT_MAX_CHARS = 250
    const val DEFAULT_MAX_CHARS_CJK = 100

    private val PARAGRAPH = Regex("\n\\s*\n")
    private val LINE_BREAK = Regex("\\s*\n\\s*")
    // Latin/Devanagari terminators need following whitespace; CJK terminators usually have none.
    private val SENTENCE_END = Regex("(?<=[.!?\u2026\u0964])\\s+|(?<=[\u3002\uFF01\uFF1F])\\s*")
    private val SOFT_BREAK = Regex("(?<=[,;:])\\s+|(?<=[\uFF0C\uFF1B\uFF1A\u3001])\\s*")

    fun defaultMaxChars(text: String): Int {
        val sample = text.take(2000)
        if (sample.isEmpty()) return DEFAULT_MAX_CHARS
        val cjk = sample.count { isCjkLike(it) }
        return if (cjk * 3 > sample.length) DEFAULT_MAX_CHARS_CJK else DEFAULT_MAX_CHARS
    }

    fun split(text: String, maxChars: Int = defaultMaxChars(text)): List<TextChunk> {
        require(maxChars >= 20) { "maxChars too small" }
        val out = mutableListOf<TextChunk>()
        val paragraphs = text.replace("\r\n", "\n").replace('\r', '\n')
            .split(PARAGRAPH).map { it.trim() }.filter { it.isNotEmpty() }
        for (paragraph in paragraphs) {
            val pieces = paragraph.replace(LINE_BREAK, " ")
                .split(SENTENCE_END).map { it.trim() }.filter { it.isNotEmpty() }
                .flatMap { splitLong(it, maxChars) }
            val chunks = mutableListOf<String>()
            val cur = StringBuilder()
            for (piece in pieces) {
                if (cur.isNotEmpty() && cur.length + 1 + piece.length > maxChars) {
                    chunks += cur.toString()
                    cur.clear()
                }
                appendJoined(cur, piece)
            }
            if (cur.isNotEmpty()) chunks += cur.toString()
            chunks.forEachIndexed { i, c ->
                out += TextChunk(c, if (i == chunks.lastIndex) PARAGRAPH_PAUSE_MS else SENTENCE_PAUSE_MS)
            }
        }
        return out
    }

    private fun splitLong(sentence: String, max: Int): List<String> {
        if (sentence.length <= max) return listOf(sentence)
        val result = mutableListOf<String>()
        val cur = StringBuilder()
        for (part in sentence.split(SOFT_BREAK).map { it.trim() }.filter { it.isNotEmpty() }) {
            if (part.length > max) {
                if (cur.isNotEmpty()) {
                    result += cur.toString()
                    cur.clear()
                }
                result += splitWords(part, max)
                continue
            }
            if (cur.isNotEmpty() && cur.length + 1 + part.length > max) {
                result += cur.toString()
                cur.clear()
            }
            appendJoined(cur, part)
        }
        if (cur.isNotEmpty()) result += cur.toString()
        return result
    }

    private fun splitWords(s: String, max: Int): List<String> {
        val result = mutableListOf<String>()
        val cur = StringBuilder()
        for (word in s.split(' ').filter { it.isNotEmpty() }) {
            if (word.length > max) {            // e.g. text without any spaces
                if (cur.isNotEmpty()) {
                    result += cur.toString()
                    cur.clear()
                }
                result += word.chunked(max)
                continue
            }
            if (cur.isNotEmpty() && cur.length + 1 + word.length > max) {
                result += cur.toString()
                cur.clear()
            }
            appendJoined(cur, word)
        }
        if (cur.isNotEmpty()) result += cur.toString()
        return result
    }

    private fun appendJoined(sb: StringBuilder, piece: String) {
        if (sb.isNotEmpty() && !isCjkLike(sb[sb.length - 1])) sb.append(' ')
        sb.append(piece)
    }

    private fun isCjkLike(c: Char): Boolean {
        val script = Character.UnicodeScript.of(c.code)
        if (script == Character.UnicodeScript.HAN ||
            script == Character.UnicodeScript.HIRAGANA ||
            script == Character.UnicodeScript.KATAKANA
        ) return true
        val block = Character.UnicodeBlock.of(c)
        return block == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION ||
            block == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
    }
}
