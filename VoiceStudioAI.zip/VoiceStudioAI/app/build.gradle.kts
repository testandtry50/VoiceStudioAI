import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// --- Pinned sherpa-onnx (see sherpa-onnx.properties) -------------------------------------------
val sherpaProps = Properties().apply {
    rootProject.file("sherpa-onnx.properties").inputStream().use { load(it) }
}
val sherpaVersion: String = sherpaProps.getProperty("version")
    ?: throw GradleException("sherpa-onnx.properties has no 'version'")
val sherpaAar = file("libs/sherpa-onnx-$sherpaVersion.aar")
if (!sherpaAar.exists()) {
    throw GradleException(
        "Missing ${sherpaAar.path}. Run scripts/fetch-sherpa-onnx.sh (the GitHub Actions build does this automatically)."
    )
}

// ABIs to package. Default arm64-v8a (nearly all current phones). Override: -PappAbis=arm64-v8a,x86_64
val appAbis = (findProperty("appAbis") as String? ?: "arm64-v8a")
    .split(",").map { it.trim() }.filter { it.isNotEmpty() }

android {
    namespace = "com.voicestudio.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.voicestudio.ai"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-phase1"
        ndk { abiFilters += appAbis }
    }

    // Fixed debug key: every CI build is signed identically, so a new APK installs over the old one
    // and the downloaded model survives. Debug key only - never use it for a release.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            storeType = "pkcs12"
        }
    }

    buildTypes { release { isMinifyEnabled = false } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // The sherpa-onnx AAR may have been compiled with a newer Kotlin than the one pinned here.
        freeCompilerArgs += "-Xskip-metadata-version-check"
    }
    buildFeatures { compose = true }
}

dependencies {
    implementation(files(sherpaAar))
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.core)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.vm.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.coroutines.android)
    implementation(libs.commons.compress)   // model archives are .tar.bz2
    testImplementation(libs.junit)
}
